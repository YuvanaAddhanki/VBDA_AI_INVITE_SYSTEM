from flask import Flask, request, render_template
import csv
app = Flask(__name__)

@app.route('/rsvp', methods=['POST'])
def rsvp():
    name = request.form['name']
    email = request.form['email']
    response = request.form['response']
    with open('../data/rsvps.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([name, email, response])
    return f"Thank you, {name}. Your response has been recorded!"

if __name__ == '__main__':
    app.run(debug=True)
